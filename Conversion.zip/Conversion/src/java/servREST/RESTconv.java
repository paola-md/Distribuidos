/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package servREST;

import javax.ws.rs.core.Context;
import javax.ws.rs.core.UriInfo;
import javax.ws.rs.Produces;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PUT;
import javax.ws.rs.PathParam;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;

/**
 * REST Web Service
 *
 * @author sdist
 */
@Path("generic")
public class RESTconv {

    @Context
    private UriInfo context;

    /**
     * Creates a new instance of RESTconv
     */
    public RESTconv() {
    }

    /**
     * Retrieves representation of an instance of servREST.RESTconv
     *
     * @return an instance of java.lang.String
     */
    @GET
    @Produces(MediaType.TEXT_HTML)
    public String getHtml(@QueryParam("cantidad") double valor, @QueryParam("have") String have, @QueryParam("want") String want) {
        nuevosCambio.Convierte_Service service = new nuevosCambio.Convierte_Service();
        nuevosCambio.Convierte port = service.getConviertePort();
        String res = "";
        if (have.equals("US") && want.equals("MX")) {
            res = "La respuesta es " + port.dolarPeso(valor);
        } else {
            if (have.equals("MX") && want.equals("US")) {
                res = "La respuesta es " + port.pesoDolar(valor);
            }
            else{
                res = "" +valor;
            }

        }

        return res;
    }

    /**
     * Retrieves representation of an instance of webservices.MyPathResource
     *
     * @return an instance of java.lang.String
     */
    /**
     * PUT method for updating or creating an instance of RESTconv
     *
     * @param content representation for the resource
     */
    @PUT
    @Consumes(MediaType.TEXT_HTML)
    public void putHtml(String content) {
    }

    private static double dolarPeso(double dolar) {
        SOAPconv.Convierte_Service service = new SOAPconv.Convierte_Service();
        SOAPconv.Convierte port = service.getConviertePort();
        return port.dolarPeso(dolar);
    }

    private static double pesoDolar(double peso) {
        nuevosCambio.Convierte_Service service = new nuevosCambio.Convierte_Service();
        nuevosCambio.Convierte port = service.getConviertePort();
        return port.pesoDolar(peso);
    }
}
