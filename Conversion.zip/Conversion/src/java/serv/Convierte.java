/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package serv;

import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.ejb.Stateless;

/**
 *
 * @author sdist
 */
@WebService(serviceName = "Convierte")
@Stateless()
public class Convierte {

    /**
     * This is a sample web service operation
     */
    @WebMethod(operationName = "hello")
    public String hello(@WebParam(name = "name") String txt) {
        return "Hello " + txt + " !";
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "dolarPeso")
    public double dolarPeso(@WebParam(name = "dolar") double dolar) {
        //TODO write your implementation code here:
        return dolar*20.1;
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "pesoDolar")
    public double pesoDolar(@WebParam(name = "peso") double peso) {
        //TODO write your implementation code here:
        return peso/20.1;
    }
}
