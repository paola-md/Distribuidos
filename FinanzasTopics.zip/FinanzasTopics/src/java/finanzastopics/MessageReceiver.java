/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package finanzastopics;

/**
 *
 * @author JGUTIERRGARC
 */
import java.util.Random;
import javax.annotation.Resource;
import javax.jms.Connection;
import javax.jms.ConnectionFactory;
import javax.jms.JMSException;
import javax.jms.MessageConsumer;
import javax.jms.Queue;
import javax.jms.Session;
import javax.jms.TextMessage;
import javax.jms.Topic;

public class MessageReceiver {

    @Resource(mappedName = "jms/GlassFishTestConnectionFactory")
    private static ConnectionFactory connectionFactory;
    @Resource(mappedName = "jms/TopicTele")
    private static Topic topicTele;
    @Resource(mappedName = "jms/TopicBanks")
    private static Topic topicBanks;
    @Resource(mappedName = "jms/TopicTransport")
    private static Topic topicTransport;
    @Resource(mappedName = "jms/TopicFood")
    private static Topic topicFood;
    @Resource(mappedName = "jms/TopicEducation")
    private static Topic topicEducation;
    
    @Resource(mappedName = "jms/GlassFishTestTopic")  
    private static Topic topic;  

    private int interes;

    public MessageReceiver(int interes) {
        this.interes = interes;
    }

    
    
    public void getMessages() {
        Connection connection;
        MessageConsumer messageConsumer;
        TextMessage textMessage;
        boolean goodByeReceived = false;
        try {
            connection = connectionFactory.createConnection();
            Session session = connection.createSession(false /*Transacter*/, Session.AUTO_ACKNOWLEDGE);

            switch (interes) {
                case (1):
                    messageConsumer = session.createConsumer(topicTele);
                    break;
                case (2):
                    messageConsumer = session.createConsumer(topicBanks);
                    break;
                case (3):
                    messageConsumer = session.createConsumer(topicTransport);
                    break;
                case (4):
                    messageConsumer = session.createConsumer(topicFood);
                    break;
                case (5):
                    messageConsumer = session.createConsumer(topicEducation);
                    break;
                default:
                    messageConsumer = session.createConsumer(topic);
            }

        
            connection.start();
            while (!goodByeReceived) {
                textMessage = (TextMessage) messageConsumer.receive();
                if (textMessage != null) {
                    // System.out.print("Received the following message: ");
                    System.out.println("Receiving terrible market news. Level: " + textMessage.getText() + " Category: " + this.interes);
                   // System.out.println(textMessage.getText());
                    System.out.println();
                }
                if (textMessage.getText() != null && textMessage.getText().equals("101")) {
                    goodByeReceived = true;
                }
            }

            messageConsumer.close();
            session.close();
            connection.close();

        } catch (JMSException e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        Random r = new Random();
        int topic;
        topic = 2;
        MessageReceiver mr = new MessageReceiver(topic);
        mr.getMessages();


    }

}
