/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package finanzastopics;

/**
 *
 * @author JGUTIERRGARC
 */
import java.util.Random;
import javax.annotation.Resource;
import javax.jms.Connection;
import javax.jms.ConnectionFactory;
import javax.jms.JMSException;
import javax.jms.MessageProducer;
import javax.jms.Queue;
import javax.jms.Session;
import javax.jms.TextMessage;
import javax.jms.Topic;

public class MessageSender {

    @Resource(mappedName = "jms/GlassFishTestConnectionFactory")
    private static ConnectionFactory connectionFactory;
    @Resource(mappedName = "jms/TopicTele")
    private static Topic topicTele;
    @Resource(mappedName = "jms/TopicBanks")
    private static Topic topicBanks;
    @Resource(mappedName = "jms/TopicTransport")
    private static Topic topicTransport;
    @Resource(mappedName = "jms/TopicFood")
    private static Topic topicFood;
    @Resource(mappedName = "jms/TopicEducation")
    private static Topic topicEducation;

    @Resource(mappedName = "jms/GlassFishTestTopic")
    private static Topic topic;

    public void produceMessages(int topico, int importance) {
        MessageProducer messageProducer;
        TextMessage textMessage;
        try {
            Connection connection = connectionFactory.createConnection();
            Session session = connection.createSession(false /*Transacter*/, Session.AUTO_ACKNOWLEDGE);
            //Topic myTopic = session.createTopic (String topicName)                 
            switch (topico) {
                case (1):
                    messageProducer = session.createProducer(topicTele);
                    break;
                case (2):
                    messageProducer = session.createProducer(topicBanks);
                    break;
                case (3):
                    messageProducer = session.createProducer(topicTransport);
                    break;
                case (4):
                    messageProducer = session.createProducer(topicFood);
                    break;
                case (5):
                    messageProducer = session.createProducer(topicEducation);
                    break;
                default:
                    messageProducer = session.createProducer(topic);
                    break;
            }

            textMessage = session.createTextMessage();

            String mensaje = "" + importance;
            textMessage.setText(mensaje);
            System.out.println("Sending terrible market news. Level: " + importance + " Category: " + topico);
            messageProducer.send(textMessage);

            messageProducer.close();
            session.close();
            connection.close();
        } catch (JMSException e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) throws InterruptedException {
        MessageSender ms = new MessageSender();
        Random r = new Random();
        int importance;
        int topic;
        for (int i = 0; i < 50; i++) {
            importance = r.nextInt(12);
            topic = r.nextInt(5);
            if(importance==11){
                importance = 101;
            }
            ms.produceMessages(topic, importance);
            Thread.sleep(800);
        }

    }
}
